import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import federation from '@originjs/vite-plugin-federation'

export default defineConfig({
  server: {
    port: 5174,
    cors: true,
    headers: {
      'Access-Control-Allow-Origin': '*'
    }
  },

  resolve: {
    dedupe: [
      'react', 
      'react-dom',
      'react/jsx-runtime',
      'react/jsx-dev-runtime',
      '@azure/msal-react', 
      '@azure/msal-browser'
    ],
  },

  plugins: [
    react(),
    federation({
      name: 'bswebapp',
      filename: 'remoteEntry.js',
      exposes: {
        './bs-element': './src/mf/defineBsElement.tsx'
      },
      
      // Use object with requiredVersion
      shared: {
        'react': {
          requiredVersion: '^19.2.0', // '19.2.0' if you use React 19
        },
        'react-dom': {
          requiredVersion: '^19.2.0',
        },
        '@azure/msal-browser': {
          requiredVersion: '^4.26.1',
        },
        '@azure/msal-react': {
          requiredVersion: '^3.0.21',
        }
      }
    })
  ],

  build: {
    target: 'esnext',
    modulePreload: false,
    cssCodeSplit: false, // Better false for MFE
    assetsInlineLimit: 0,
    minify: false, // Disabled for debug
    rollupOptions: {

      external: ['react', 'react-dom', ]

    }
  },

  // Configure optimizeDeps for MFE
  optimizeDeps: {
    
    include: [
      // Add react and react-dom
      'react',
      'react/jsx-runtime',
      'react/jsx-dev-runtime',
      'react-dom',
      'react-dom/client',
      '@azure/msal-browser',
      '@azure/msal-react',
      'cookie',
      'set-cookie-parser'
    ],
    
    // Force ESM
    esbuildOptions: {
      mainFields: ['module', 'main'],
    }
  },
  preview: {
    port: 5174,
    cors: true,
  },
})
