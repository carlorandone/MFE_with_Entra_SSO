import React from 'react'
//import ReactDOM from 'react-dom/client'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { PublicClientApplication } from '@azure/msal-browser'
import { MsalProvider, useIsAuthenticated, useMsal } from '@azure/msal-react'
import BsHome from './components/BsHome'
import { msalConfigBs, loginRequest } from './msalConfigBs'
import { InteractionStatus } from '@azure/msal-browser'

import AuthCallback from './pages/AuthCallback'

const pca = new PublicClientApplication(msalConfigBs)
//pca.handleRedirectPromise().catch((e)=>console.warn('MSAL redirect error', e))

// INITIALIZE PCA asynchronously
async function initializeMsal() {
  await pca.initialize()
  await pca.handleRedirectPromise().catch((e) => console.warn('MSAL redirect error', e))
}

function Shell() {
  const isAuth = useIsAuthenticated()
  const { instance, inProgress } = useMsal()

  const [redirectAttempted, setRedirectAttempted] = React.useState(false)
    React.useEffect(() => {
    console.log('[Shell] isAuth:', isAuth, 'inProgress:', inProgress)
  }, [isAuth, inProgress])

  React.useEffect(() => {
    if (isAuth) {
      console.log('[Shell] Usr already authenticated')
      return
    }

    if (inProgress !== InteractionStatus.None) {
      console.log('[Shell] Interaction in progress:', inProgress)
      return
    }
    if (redirectAttempted) {
      console.log('[Shell] Redirect already attempted')
      return
    }
    console.log('[Shell] Start loginRedirect...')
    setRedirectAttempted(true)

    instance.loginRedirect(loginRequest)
      .then(() => console.log('[Shell] loginRedirect started'))
      .catch((error) => {
        console.error('[Shell] loginRedirect FAILED:', error)
        setRedirectAttempted(false)
      })
  }, [isAuth, inProgress, instance, redirectAttempted])


  // Do not render anything unless authenticated
  /* */
  if (!isAuth && !window.location.pathname.includes('/auth/callback')) {
    // Do not show message on callback (handled by AuthCallback)
    return (
      <div style={{ padding: 24, fontFamily: 'system-ui, Segoe UI, Roboto' }}>
        <h2>BSWebApp</h2>
        {inProgress !== InteractionStatus.None ? (
          <p>Inizializzazione…</p>
        ) : redirectAttempted ? (
          <p>Reindirizzamento in corso…</p>
        ) : (
          <p>Preparazione autenticazione…</p>
        )}
      </div>
    )
  }
  
  
  // Render routes ONLY when authenticated
  return (
    <Routes>
      <Route path="/" element={<BsHome />} />
      <Route path="/auth/callback" element={<AuthCallback />} />  {/* Use the component */}
    </Routes>
  )
}

// Initialize MSAL then render the app
initializeMsal().then(() => {
  console.log('[main.tsx] MSAL initialized, app rendering...')
  
  createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <MsalProvider instance={pca}>
        <BrowserRouter>
          <Shell />
        </BrowserRouter>
      </MsalProvider>
    </React.StrictMode>
  )
}).catch((error) => {
  console.error('[main.tsx] MSAL initialization error:', error)
  document.getElementById('root')!.innerHTML = `
    <div style="padding: 24px; font-family: system-ui;">
      <h2>Initialization error</h2>
      <p>Unable to initialize authentication system.</p>
      <pre>${error.message}</pre>
    </div>
  `
})



