import React from 'react'
import { useMsal, useIsAuthenticated } from '@azure/msal-react'

export default function BsHome() {

    const { instance } = useMsal()
    const isAuthenticated = useIsAuthenticated()
    const account = isAuthenticated ? instance.getAllAccounts()[0] : null

    const [open, setOpen] = React.useState(false)
    return (
        <div style={{ fontFamily: 'system-ui, Segoe UI, Roboto',
            backgroundColor: '#e6f2ff',
            padding: '16px',
            borderRadius: '4px',
            minHeight: '200px'
        }}>

        <h2>BSWebApp - Home</h2>
        <p>Questa è la home di BSWebApp (SPA e Web Component).</p>

        {/* Show user information */}
        {isAuthenticated ? (
            <p>
                <strong>Authenticated User:</strong> {account?.name} ({account?.username})
            </p>
        ) : (
            <p>
                <em>No authenticated user</em>
            </p>
            )}

        <button onClick={() => setOpen(true)}>Open test modal</button>
        {open && (
            <div style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.35)',
            display:'grid', placeItems:'center', zIndex: 1000
            }}>
            <div style={{ background:'#fff', padding: 20, minWidth: 320, borderRadius: 8 }}>
                <h3>BSWebApp Modal</h3>
                <p>Example content.</p>
                <button onClick={() => setOpen(false)}>Close</button>
            </div>
            </div>
        )}
        <div style={{ marginTop: 16, padding: 12, border: '1px solid #ddd' }}>
            <p>Protected content of the BSWebApp.</p>
        </div>
        </div>
    )
}
