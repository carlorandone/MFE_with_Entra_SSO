//import React from 'react'
//import ReactDOM from 'react-dom/client'
import { type Root } from 'react-dom/client'
import { BSWebComponentRoot } from './BSWebComponent'

import * as ReactNS from 'react'

const React = (window as any).__HOST_REACT__ || await import('react')

/**
* Defines <bs-home> as Custom Element.
* Run React inside a dedicated shadow host.
*/
class BsHomeElement extends HTMLElement {
    private root?: Root
    private mountPoint?: HTMLDivElement

    async connectedCallback() {
        if (!this.mountPoint) {
        const shadow = this.attachShadow({ mode: 'open' })
        this.mountPoint = document.createElement('div')
        shadow.appendChild(this.mountPoint)
        //this.root = createRoot(this.mountPoint)
        const ReactDOM = (window as any).__HOST_REACT_DOM__ || await import('react-dom/client')
        this.root = ReactDOM.createRoot(this.mountPoint)
        }

        // Reads attributes passed from container (SCPortal)
        const loginhint = this.getAttribute('loginhint') ?? undefined
        const domainhint = this.getAttribute('domainhint') ?? undefined
        const sid = this.getAttribute('sid') ?? undefined

        console.log('REMOTE React identity same as HOST?', ReactNS === (window as any).__HOST_REACT__)

        this.root!.render(
        <React.StrictMode>
            <BSWebComponentRoot loginhint={loginhint} domainhint={domainhint} sid={sid} />
        </React.StrictMode>
        )
    }

    disconnectedCallback() {
        // optional: unmount for cleanup
        // this.root?.unmount()
    }
    }

    if (!customElements.get('bs-home')) {
    customElements.define('bs-home', BsHomeElement)
}

// Necessary for import from host (side-effect define)
export {}

