import React from 'react'
import { PublicClientApplication, InteractionStatus } from '@azure/msal-browser'
import { MsalProvider, useIsAuthenticated, useMsal } from '@azure/msal-react'
import { msalConfigBsMfe, loginRequest } from '../msalConfigBsMfe'
import BsHome from '../components/BsHome'

/**
* React wrapper that:
* - use MSAL
* - Attempt SSO with ssoSilent() using loginhint/domainhint/sid passed from host
* - fallback to loginRedirect (redirect to hostredirecturi if configured)
*/
function Inner({ loginHint, domainHint, sid }: { loginHint?: string, domainHint?: string, sid?: string }) {
    const isAuth = useIsAuthenticated()
    const { instance, inProgress } = useMsal()
    const [ssoError, setSsoError] = React.useState<string | null>(null)

    React.useEffect(() => {

          // Log BEFORE check

        console.log("*** BSWebComponent.tsx - Inner - useEffect triggered");
        console.log("   isAuth:", isAuth);
        console.log("   inProgress:", inProgress);
        console.log("   loginHint:", loginHint);
        console.log("   domainHint:", domainHint);

        if (isAuth || inProgress !== InteractionStatus.None) {
            console.log("*** SKIP ssoSilent - already authenticated or interaction in progress");
            return;
        }

        // First attempt: silent SSO
        // This is executed ONLY if NOT authenticated
        console.log("*** in BSWebApp - BSWebComponent.tsx - before ssoSilent()");

        instance.ssoSilent({ ...loginRequest, loginHint, domainHint, sid, prompt: 'none' })
        .then((result) => {

            // Here it is executed ONLY if ssoSilent succeeds
            console.log("*** ssoSilent SUCCESS - result:", result);
            console.log("*** Account:", result.account);
            console.log("*** AccessToken:", result.accessToken ? "present" : "absent");
        })
        .catch((e) => {
            console.warn('ssoSilent failed - Try loginRedirect', e)
            setSsoError(e?.message || 'Silent SSO failed')
            // Fallback: redirect (user-interactive) – uses already active Enter session ⇒ no input
            instance.loginRedirect(loginRequest).catch(console.error)
        })
    }, [isAuth, inProgress, instance, loginHint, domainHint, sid])

    if (!isAuth) {
        return (
        <div style={{ padding: 16 }}>
            <h3>BSWebApp</h3>
            <p>Tentativo di Single Sign On…</p>
            {ssoError && <small style={{ color:'#a00' }}>{ssoError}</small>}
        </div>
        )
    }

    return <BsHome />
}

/*
* Create separate PCA instance (but shared libraries are singletons via MF)
* redirectUri is already set to host (if defined in .env)
*/
const pca = new PublicClientApplication(msalConfigBsMfe)

// Initialize immediately

const pcaInitPromise = pca.initialize()
    .then(() => pca.handleRedirectPromise())
    .then(() => {
        console.log('[BSWebComponent] PCA initialized')
    })
    .catch((e) => {
        console.warn('[BSWC] Initialization error:', e)
    })

export function BSWebComponentRoot(props: { loginhint?: string, domainhint?: string, sid?: string }) {

    console.log("*** BSWebComponentRoot render");
    console.log("   Props:", props);

    const [ready, setReady] = React.useState(false)

    // Wait for PCA to initialize
    React.useEffect(() => {
        pcaInitPromise.then(() => setReady(true))
    }, [])

    console.log("*** BSWebComponentRoot render - ready:", ready);

    if (!ready) {
        return (
            <div style={{ padding: 16 }}>
                <p>Authentication initialization...</p>
            </div>
        )
    }

    return (
        <MsalProvider instance={pca}>
        <Inner loginHint={props.loginhint} domainHint={props.domainhint} sid={props.sid} />
        </MsalProvider>
    )
}
