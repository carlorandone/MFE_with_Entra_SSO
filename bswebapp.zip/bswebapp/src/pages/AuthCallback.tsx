import React from 'react'
import { useIsAuthenticated } from '@azure/msal-react'
import { useNavigate, useLocation } from 'react-router-dom'

export default function AuthCallback() {
    const isAuthenticated = useIsAuthenticated()
    const navigate = useNavigate()
    const location = useLocation()

    React.useEffect(() => {
        console.log('[AuthCallback] isAuthenticated:', isAuthenticated)
        
        if (isAuthenticated) {
            // After authentication, return to the home page
            const from = (location.state as any)?.from || '/'
            console.log('[AuthCallback] Redirect to:', from)
            navigate(from, { replace: true })
        }
    }, [isAuthenticated, navigate, location.state])

    return (
        <div style={{ padding: 24, fontFamily: 'system-ui, Segoe UI, Roboto' }}>
            <h2>BSWebApp</h2>
            <p>Completing login...</p>
        </div>
    )
}
