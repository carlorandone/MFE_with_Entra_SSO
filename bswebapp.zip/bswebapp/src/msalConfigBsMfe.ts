import type { Configuration } from '@azure/msal-browser'
import { LogLevel } from '@azure/msal-browser'

const tenantId = import.meta.env.VITE_TENANT_ID as string
const clientId = import.meta.env.VITE_BS_CLIENT_ID as string

// Two possible redirects: native BS redirect or host redirect (recommended in MF)
const redirectUriHost = import.meta.env.VITE_HOST_REDIRECT_URI as string | undefined
//const redirectUriLocal = import.meta.env.VITE_BS_REDIRECT_URI as string | undefined

console.log('[msalConfigBs] Configuration STANDALONE')
console.log('  tenantId:', tenantId)
console.log('  clientId:', clientId)
console.log('  redirectUri:', redirectUriHost || window.location.origin)

export const msalConfigBsMfe: Configuration = {
    auth: {
        clientId,
        authority: `https://login.microsoftonline.com/${tenantId}/v2.0`,
        knownAuthorities: ['login.microsoftonline.com'],
        redirectUri: redirectUriHost || window.location.origin,
        navigateToLoginRequestUrl: false
    },
    cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: false
    },
    system: {
        loggerOptions: {
        loggerCallback: (_l, m) => console.debug('[MSAL][BSWebApp]', m),
        logLevel: LogLevel.Info,
        piiLoggingEnabled: false
        }
    }
}

export const loginRequest = {
    scopes: ['openid', 'profile', 'email']
}
