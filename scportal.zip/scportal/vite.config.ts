import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import federation from '@originjs/vite-plugin-federation'

export default defineConfig({
  server: {
    port: 5173
  },

  
  resolve: {
    // Avoid multiple copies of these packages in the dependency tree
    dedupe: ['react', 'react-dom',
      'react/jsx-runtime',
      'react/jsx-dev-runtime',
      '@azure/msal-react', '@azure/msal-browser'],
  },

  plugins: [
    react(),
    federation({
      name: 'scportal',
      remotes: {
        // Remote entry of BSWebApp (dev)
        bswebapp: 'http://localhost:5174/assets/remoteEntry.js'
      },
      // With OriginJS, don't use `singleton`: it's not typed/supported.
      // We maintain declarative sharing for key dependencies.

      /*
      shared: {
        react: { version: '19.2.0' },
        'react-dom': { version: '19.2.0' },
        '@azure/msal-browser': { version: '^4.26.1' },
        '@azure/msal-react': { version: '^3.0.21' },
      }
      */

      /* */
      shared: {
        react: {
          requiredVersion: '^19.2.0',
        },
        'react-dom': {
          requiredVersion: '^19.2.0',
        },
        '@azure/msal-browser':{requiredVersion: '^4.26.1',},
        '@azure/msal-react':{requiredVersion: '^3.0.21',},
      }
      /* */

      // Alternatively (if you want to use objects), do NOT include `singleton`:
      // shared: {
      //   react: { eager: true },
      //   'react-dom': { eager: true },
      //   '@azure/msal-browser': { eager: true },
      //   '@azure/msal-react': { eager: true }
      // }
    })
  ],
  build: {
    target: 'esnext',
    modulePreload: false,   // required for MF with Vite
    cssCodeSplit: true,
    assetsInlineLimit: 0
  },
  
  optimizeDeps: {
    noDiscovery: true,  // disable automatic scanning
    include: ['react', 'react-dom', 'react-dom/client', 'cookie', 'set-cookie-parser'],
    entries: [],        // Prevents using your app's entries for pre-bundling
    
    // Help esbuild choose the ESM build when available
    esbuildOptions: {
      mainFields: ['module', 'jsnext:main', 'browser', 'main'],
    },

    
  },

})

