//import React from 'react'
import { Link } from 'react-router-dom'
import { useMsal, useIsAuthenticated } from '@azure/msal-react'

export default function Home() {
    const { instance } = useMsal()
    const isAuthenticated = useIsAuthenticated()
    const account = isAuthenticated ? instance.getAllAccounts()[0] : null
    

    return (
        <div>
        <h1>Home SCPortal</h1>
        {isAuthenticated ? (
            <p>Utente: {account?.name} ({account?.username})</p>
        ) : (
            <p>Not authenticated. Click <strong>Login</strong> on top to access.</p>
        )}
        <p>
            Go to <Link to="/pagina-bs">PaginaBS</Link> to use the BSWebApp web component.
        </p>
        </div>
    )

}
