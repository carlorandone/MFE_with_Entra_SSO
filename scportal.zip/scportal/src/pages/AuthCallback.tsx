import React from 'react'
import { useIsAuthenticated } from '@azure/msal-react'
import { useLocation, useNavigate } from 'react-router-dom'

export default function AuthCallback() {
    const isAuthenticated = useIsAuthenticated()
    const navigate = useNavigate()
    const location = useLocation()

    React.useEffect(() => {
        if (isAuthenticated) {
        // If RequireAuth passed a state.from we use it, otherwise fallback to "/"
        const from = (location.state as any)?.from || '/'
        navigate(from, { replace: true })
        }
    }, [isAuthenticated, navigate, location.state])

    return <div>Login completion...</div>
}