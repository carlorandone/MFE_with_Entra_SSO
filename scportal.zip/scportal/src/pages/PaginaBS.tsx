import React from 'react'
import { Link } from 'react-router-dom'
import { useMsal } from '@azure/msal-react'

// Lazy load of the remote and custom element definition
async function ensureBsElementDefined() {
    if (!customElements.get('bs-home')) {
        // Dynamic import from the remote exposed by Module Federation
        await import('bswebapp/bs-element')

        console.log("*** In PaginaBS.tsx: after await import bswebapp/bs-element ***");
    
    }
}


export default function PaginaBS() {
    const { instance } = useMsal()
    const account = instance.getAllAccounts()[0] || null

    const loginHint = account?.username || ''
    const domainHint = (import.meta.env.VITE_DOMAIN_HINT as string) || ''


    const [ready, setReady] = React.useState(false)

    React.useEffect(() => {
        ensureBsElementDefined().then(() => setReady(true))
    }, [])

    return (
        <div style={{ minHeight: '60vh' }}>
        <h1>PaginaBS (hosted by SCPortal)</h1>
        <p>Below is a rendering of the <strong>BSWebApp</strong> Home exposed as a Web Component.</p>

        {ready ? (
                <div style={{ 
                    border: '3px solid #007bff',
                    borderRadius: '8px',
                    padding: '20px',
                    margin: '20px 0'
                }}>
                    <p style={{ 
                        color: '#007bff', 
                        fontWeight: 'bold', 
                        marginTop: 0,
                        fontSize: '14px'
                    }}>
                        ↓ START Microfrontend BSWebApp ↓
                    </p>
            <bs-home
            loginhint={loginHint || ''}
            domainhint={domainHint || ''}
            hostredirecturi={import.meta.env.VITE_SC_REDIRECT_URI}
            ></bs-home>
            <p style={{ 
                        color: '#007bff', 
                        fontWeight: 'bold', 
                        marginBottom: 0,
                        fontSize: '14px'
                    }}>
                        ↑ END Microfrontend BSWebApp ↑
                    </p>
                </div>
        ) : (
            <p>Micro Frontend loading...</p>
        )}

        <hr style={{ margin: '24px 0' }} />
        <p>
            <Link to="/">Return to SCPortal Home</Link>
        </p>
        </div>
    )
}
