import React from 'react'
//import ReactDOM from 'react-dom/client'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { PublicClientApplication } from '@azure/msal-browser'
import { MsalProvider } from '@azure/msal-react'
import App from './App'
import { msalConfig } from './msalConfig'

import * as ReactNS from 'react'

import * as ReactDOMNS from 'react-dom/client'

;(window as any).__HOST_REACT__ = ReactNS

;(window as any).__HOST_REACT_DOM__ = ReactDOMNS

const pca = new PublicClientApplication(msalConfig)
// manages any pending redirects
pca.handleRedirectPromise().catch((e) => console.warn('MSAL redirect error', e))

createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <MsalProvider instance={pca}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </MsalProvider>
  </React.StrictMode>
)
