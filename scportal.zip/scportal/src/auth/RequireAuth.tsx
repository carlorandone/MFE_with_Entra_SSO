// scportal/src/auth/RequireAuth.tsx

//import React from 'react'
import { useLocation } from 'react-router-dom'
import { useIsAuthenticated, useMsal } from '@azure/msal-react'
import { InteractionStatus } from '@azure/msal-browser'
import { loginRequest } from '../msalConfig'

type Props = {
    children: React.ReactNode
    /** Avoid forced redirection on the callback route to avoid creating loops */
    disableRedirectOnThisRoute?: boolean
    }

    export default function RequireAuth({ children, disableRedirectOnThisRoute = false }: Props) {
    const { instance, inProgress } = useMsal()
    const isAuthenticated = useIsAuthenticated()
    const location = useLocation()

    // Wait until MSAL is not interacting (redirect/handle in progress)
    if (inProgress !== InteractionStatus.None) {
        return <div>Inizializzazione della sessione…</div>
    }

    if (!isAuthenticated && !disableRedirectOnThisRoute) {
        // save the origin page for post-login return
        const state = JSON.stringify({ from: location.pathname + location.search })
        
        instance.loginRedirect({ ...loginRequest, state }).catch(console.error)
        return <div>Reindirizzamento per l’accesso…</div>
    }

    if (!isAuthenticated && disableRedirectOnThisRoute) {
        return <div>Login completion...</div>
    }

    return <>{children}</>
}
