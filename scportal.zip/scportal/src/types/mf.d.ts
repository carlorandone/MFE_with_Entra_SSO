// Declare the remote module exposed by BSWebApp
declare module 'bswebapp/bs-element' {
  // does not export symbols: the side‑effect is the define() of the custom element
    const nothing: unknown
    export default nothing
}