// types/jsx.d.ts
import 'react';

declare module 'react' {
    namespace JSX {
        interface IntrinsicElements {
        'bs-home': React.DetailedHTMLProps<
            React.HTMLAttributes<HTMLElement>,
            HTMLElement
        > & {
            loginhint?: string;
            domainhint?: string;
            hostredirecturi?: string;
            sid?: string;
        };
        }
    }
}
