import type { Configuration } from '@azure/msal-browser'
import { LogLevel } from '@azure/msal-browser'


const tenantId = import.meta.env.VITE_TENANT_ID as string
const clientId = import.meta.env.VITE_SC_CLIENT_ID as string
const redirectUri = import.meta.env.VITE_SC_REDIRECT_URI as string

export const msalConfig: Configuration = {
    auth: {
        clientId,
        authority: `https://login.microsoftonline.com/${tenantId}/v2.0`,
        knownAuthorities: [`login.microsoftonline.com`],
        redirectUri,
        navigateToLoginRequestUrl: false
    },
    cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: false
    },
    system: {
        loggerOptions: {
        loggerCallback: (_l, m) => console.debug('[MSAL][SCPortal]', m),
        logLevel: LogLevel.Info,
        piiLoggingEnabled: false
        }
    }
}

export const loginRequest = {
    scopes: ['openid', 'profile', 'email']
}
