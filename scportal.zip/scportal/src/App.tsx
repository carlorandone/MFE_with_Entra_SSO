// scportal/src/App.tsx
//import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import { useIsAuthenticated, useMsal } from '@azure/msal-react'
import Home from './pages/Home'
import PaginaBS from './pages/PaginaBS'
import { loginRequest } from './msalConfig'
import RequireAuth from './auth/RequireAuth'
import AuthCallback from './pages/AuthCallback'

export default function App() {
  const isAuthenticated = useIsAuthenticated()
  const { instance } = useMsal()

  return (
    <div style={{ fontFamily: 'system-ui, Segoe UI, Roboto', padding: 16 }}>
      <header style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        <strong>SCPortal</strong>
        <Link to="/">Home</Link>
        <Link to="/pagina-bs">PaginaBS</Link>
        <span style={{ flex: 1 }} />
        {isAuthenticated ? (
          <button onClick={() => instance.logoutRedirect({ postLogoutRedirectUri: '/' })}>
            Logout
          </button>
        ) : (
          <button onClick={() => instance.loginRedirect(loginRequest)}>Login</button>
        )}
      </header>

      <main style={{ marginTop: 16 }}>
        <Routes>
          {/* Callback: no forced redirect, AuthCallback takes care of navigating */}
          <Route
            path="/auth/callback"
            element={
              <RequireAuth disableRedirectOnThisRoute>
                <AuthCallback />
              </RequireAuth>
            }
          />

          {/* Non Protected Home */}
          <Route
            path="/"
            element={
              
                <Home />
              
            }
          />

          {/* Protected PaginaBS */}
          <Route
            path="/pagina-bs"
            element={
              <RequireAuth>
                <PaginaBS />
              </RequireAuth>
            }
          />

          <Route path="*" element={<div>404</div>} />
        </Routes>
      </main>
    </div>
  )
}

